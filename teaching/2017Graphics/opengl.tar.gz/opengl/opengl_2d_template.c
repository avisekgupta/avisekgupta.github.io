#include <GL/gl.h>
#include <GL/glut.h>
#include <GL/glu.h>
//#include <windows.h>  // for MS Windows

void setup() { /* empty function  nothing to setup yet */ }
void display() { /* empty function   required as of glut 3.0 */ }

int main(int argc, char *argv[])
{
        glutInit(&argc, argv); // Starts up GLUT for our use
                
        glutInitWindowSize(800,600);
        glutCreateWindow("Hello World");
        
        setup();
        glutDisplayFunc(display);
        
        glutMainLoop();
        return 0;
}